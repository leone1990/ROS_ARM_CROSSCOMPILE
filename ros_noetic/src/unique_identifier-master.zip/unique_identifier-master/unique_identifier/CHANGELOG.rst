Change history
==============

1.0.6 (2017-04-04)
------------------

1.0.5 (2015-04-17)
------------------

1.0.4 (2014-04-30)
------------------

 * add architecture independent tag

1.0.3 (2013-07-24)
------------------

1.0.2 (2013-07-18)
-------------------

 * Add missing metapackage dependency on catkin (`#5`_).

1.0.1 (2013-03-25)
-------------------

 * Hydro release update.

1.0.0 (2013-03-18)
-------------------

 * Hydro release.
 * Convert to catkin (`#1`_).
 * Make **unique_identifier** into a metapackage, depending on the
   **uuid_msgs** and **unique_id** packages. It should only be used
   for dependencies in dry stacks. Wet packages will depend directly
   on **uuid_msgs** and **unique_id**.

0.9.0 (2013-01-03)
------------------

 * Initial release to Groovy.

0.8.0 (2012-07-19)
------------------

 * Initial release to Fuerte.

.. _`#1`: https://github.com/ros-geographic-info/unique_identifier/issues/1
.. _`#5`: https://github.com/ros-geographic-info/unique_identifier/issues/5
